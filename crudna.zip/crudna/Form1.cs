using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace crudna
{
    public partial class Form1 : Form
    {
        // Connection string to Access database
        private string accessConnStr = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={Application.StartupPath}\\crud.accdb";

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadDataIntoDataGridView();
        }

        private void LoadDataIntoDataGridView()
        {
            using (OleDbConnection oleDbConnection = new OleDbConnection(accessConnStr))
            {
                try
                {
                    // Replace 'crud' with the actual table name in your Access database
                    string query = "SELECT * FROM crud";
                    OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, oleDbConnection);
                    DataTable dataTable = new DataTable();
                    dataAdapter.Fill(dataTable);

                    dataGridView1.DataSource = dataTable;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred while loading data: {ex.Message}");
                }
            }
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            // Create an instance of Form2
            Form2 frm = new Form2();

            // Show Form2 as a dialog (modal window)
            frm.ShowDialog();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            // Handle cell content clicks in dataGridView1 if needed
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a row to edit.");
                return;
            }

            // Get the selected row
            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];

            // Convert the ID to string
            string id = selectedRow.Cells["adminID"].Value?.ToString();

            if (!string.IsNullOrEmpty(id))
            {
                // Create an instance of Form2 and pass the ID of the selected record
                Form2 editForm = new Form2(id);

                // Show the form as a dialog
                editForm.ShowDialog();

                // Reload data to reflect changes
                LoadDataIntoDataGridView();
            }
            else
            {
                MessageBox.Show("Invalid ID value.");
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
