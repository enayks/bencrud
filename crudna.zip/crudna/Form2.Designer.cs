﻿namespace crudna
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            txtadmin = new TextBox();
            txtfn = new TextBox();
            label2 = new Label();
            txtln = new TextBox();
            label3 = new Label();
            btnsave = new Button();
            btncancel = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(72, 41);
            label1.Name = "label1";
            label1.Size = new Size(72, 20);
            label1.TabIndex = 0;
            label1.Text = "Admin ID";
            // 
            // txtadmin
            // 
            txtadmin.Location = new Point(150, 38);
            txtadmin.Name = "txtadmin";
            txtadmin.Size = new Size(276, 27);
            txtadmin.TabIndex = 1;
            // 
            // txtfn
            // 
            txtfn.Location = new Point(150, 87);
            txtfn.Name = "txtfn";
            txtfn.Size = new Size(276, 27);
            txtfn.TabIndex = 3;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(64, 90);
            label2.Name = "label2";
            label2.Size = new Size(80, 20);
            label2.TabIndex = 2;
            label2.Text = "First Name";
            // 
            // txtln
            // 
            txtln.Location = new Point(150, 141);
            txtln.Name = "txtln";
            txtln.Size = new Size(276, 27);
            txtln.TabIndex = 5;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(65, 144);
            label3.Name = "label3";
            label3.Size = new Size(79, 20);
            label3.TabIndex = 4;
            label3.Text = "Last Name";
            // 
            // btnsave
            // 
            btnsave.BackColor = Color.Green;
            btnsave.Location = new Point(133, 189);
            btnsave.Name = "btnsave";
            btnsave.Size = new Size(94, 29);
            btnsave.TabIndex = 6;
            btnsave.Text = "&Save";
            btnsave.UseVisualStyleBackColor = false;
            btnsave.Click += btnSave_Click;
            // 
            // btncancel
            // 
            btncancel.BackColor = Color.Tomato;
            btncancel.Location = new Point(233, 189);
            btncancel.Name = "btncancel";
            btncancel.Size = new Size(94, 29);
            btncancel.TabIndex = 8;
            btncancel.Text = "&Cancel";
            btncancel.UseVisualStyleBackColor = false;
            btncancel.Click += btnCancel_Click; // Ensure this matches the method name
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btncancel);
            Controls.Add(btnsave);
            Controls.Add(txtln);
            Controls.Add(label3);
            Controls.Add(txtfn);
            Controls.Add(label2);
            Controls.Add(txtadmin);
            Controls.Add(label1);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private TextBox txtadmin;
        private TextBox txtfn;
        private Label label2;
        private TextBox txtln;
        private Label label3;
        private Button btnsave;
        private Button btncancel;
    }
}
