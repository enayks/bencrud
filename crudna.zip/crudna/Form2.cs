﻿using System;
using System.Data;
using System.Data.OleDb;
using System.Windows.Forms;

namespace crudna
{
    public partial class Form2 : Form
    {
        private readonly string accessConnStr = $"Provider=Microsoft.ACE.OLEDB.12.0;Data Source={Application.StartupPath}\\crud.accdb";
        private readonly OleDbConnection oleDbConnection;
        private readonly string? adminID; // adminID for the record to edit (null for new record)

        public Form2(string? id = null)
        {
            InitializeComponent();
            oleDbConnection = new OleDbConnection(accessConnStr);
            adminID = id;
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(adminID))
            {
                // Load existing data for the record to edit
                LoadRecordData();
            }
        }

        private void LoadRecordData()
        {
            try
            {
                string query = "SELECT * FROM crud WHERE adminID = ?";
                using (OleDbCommand command = new OleDbCommand(query, oleDbConnection))
                {
                    command.Parameters.AddWithValue("?", adminID ?? throw new InvalidOperationException("adminID cannot be null."));
                    ManageConnection(oleDbConnection);

                    using (OleDbDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            // Populate form fields with data
                            txtadmin.Text = reader["adminID"].ToString();
                            txtfn.Text = reader["fn"].ToString();
                            txtln.Text = reader["ln"].ToString();
                        }
                        else
                        {
                            MessageBox.Show("No record found with the specified adminID.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while loading data: {ex.Message}");
            }
            finally
            {
                if (oleDbConnection.State == ConnectionState.Open)
                {
                    oleDbConnection.Close();
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(adminID))
            {
                // Update existing record
                UpdateRecord();
            }
            else
            {
                // Insert new record
                InsertRecord();
            }
        }

        private void InsertRecord()
        {
            try
            {
                string query = "INSERT INTO crud (adminID, fn, ln) VALUES (?, ?, ?)";
                using (OleDbCommand command = new OleDbCommand(query, oleDbConnection))
                {
                    command.Parameters.AddWithValue("?", txtadmin.Text);
                    command.Parameters.AddWithValue("?", txtfn.Text);
                    command.Parameters.AddWithValue("?", txtln.Text);

                    ManageConnection(oleDbConnection);
                    int rowsAffected = command.ExecuteNonQuery();

                    MessageBox.Show(rowsAffected > 0 ? "Data saved to Access database." : "No data was saved.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while saving to the Access database: {ex.Message}");
            }
            finally
            {
                if (oleDbConnection.State == ConnectionState.Open)
                {
                    oleDbConnection.Close();
                }
            }
        }

        private void UpdateRecord()
        {
            try
            {
                string query = "UPDATE crud SET fn = ?, ln = ? WHERE adminID = ?";
                using (OleDbCommand command = new OleDbCommand(query, oleDbConnection))
                {
                    command.Parameters.AddWithValue("?", txtfn.Text);
                    command.Parameters.AddWithValue("?", txtln.Text);
                    command.Parameters.AddWithValue("?", adminID ?? throw new InvalidOperationException("adminID cannot be null."));

                    ManageConnection(oleDbConnection);
                    int rowsAffected = command.ExecuteNonQuery();

                    MessageBox.Show(rowsAffected > 0 ? "Data updated successfully." : "No data was updated.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while updating the Access database: {ex.Message}");
            }
            finally
            {
                if (oleDbConnection.State == ConnectionState.Open)
                {
                    oleDbConnection.Close();
                }
            }
        }

        private void ManageConnection(IDbConnection conn)
        {
            try
            {
                if (conn.State == ConnectionState.Closed)
                {
                    conn.Open();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"An error occurred while managing the connection: {ex.Message}");
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
