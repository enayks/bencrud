﻿namespace crudna
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtuser = new TextBox();
            txtpass = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            login = new Button();
            cancel = new Button();
            SuspendLayout();
            // 
            // txtuser
            // 
            txtuser.Location = new Point(110, 78);
            txtuser.Name = "txtuser";
            txtuser.Size = new Size(260, 27);
            txtuser.TabIndex = 0;
            // 
            // txtpass
            // 
            txtpass.Location = new Point(110, 136);
            txtpass.Name = "txtpass";
            txtpass.Size = new Size(260, 27);
            txtpass.TabIndex = 1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(12, 78);
            label1.Name = "label1";
            label1.Size = new Size(75, 20);
            label1.TabIndex = 2;
            label1.Text = "Username";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(12, 139);
            label2.Name = "label2";
            label2.Size = new Size(70, 20);
            label2.TabIndex = 3;
            label2.Text = "Password";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Showcard Gothic", 18F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.Location = new Point(126, 19);
            label3.Name = "label3";
            label3.Size = new Size(112, 37);
            label3.TabIndex = 4;
            label3.Text = "log in";
            // 
            // login
            // 
            login.BackColor = Color.FromArgb(128, 255, 128);
            login.Location = new Point(163, 192);
            login.Name = "login";
            login.Size = new Size(94, 29);
            login.TabIndex = 5;
            login.Text = "&Login";
            login.UseVisualStyleBackColor = false;
            login.Click += login_Click;
            // 
            // cancel
            // 
            cancel.BackColor = Color.Red;
            cancel.Location = new Point(276, 192);
            cancel.Name = "cancel";
            cancel.Size = new Size(94, 29);
            cancel.TabIndex = 6;
            cancel.Text = "&Cancel";
            cancel.UseVisualStyleBackColor = false;
            cancel.Click += cancel_Click_1;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(382, 233);
            Controls.Add(cancel);
            Controls.Add(login);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(txtpass);
            Controls.Add(txtuser);
            Name = "Form3";
            Text = "Form3";
            Load += Form3_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtuser;
        private TextBox txtpass;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button login;
        private Button cancel;
    }
}