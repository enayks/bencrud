﻿using System;
using System.Windows.Forms;

namespace crudna
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Any initialization code
        }

        private void login_Click(object sender, EventArgs e)
        {
            // Validate user credentials
            string username = txtuser.Text;
            string password = txtpass.Text;

            // Check credentials (for example purposes, replace with actual validation)
            if (username == "admin" && password == "password")
            {
                // Set DialogResult to OK and close the form if login is successful
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            else
            {
                // Show an error message or handle failed login
                MessageBox.Show("Invalid username or password.");
            }
        }

        private void cancel_Click_1(object sender, EventArgs e)
        {
            // Set DialogResult to Cancel and close the form if login is canceled
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }
    }
}
