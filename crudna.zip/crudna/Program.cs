using System;
using System.Windows.Forms;

namespace crudna
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Create and show the login form
            Form3 loginForm = new Form3();
            DialogResult result = loginForm.ShowDialog();

            // Check the result of the login form
            if (result == DialogResult.OK) // or use a specific condition if you handle results differently
            {
                // If login is successful, create and show the main form
                Application.Run(new Form1());
            }
            else
            {
                // If login is canceled or failed, exit the application
                Application.Exit();
            }
        }
    }
}
